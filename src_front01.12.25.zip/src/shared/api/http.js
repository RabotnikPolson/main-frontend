import axios from "axios";

const baseURL = import.meta.env.VITE_API_URL || "http://localhost:8080";

const http = axios.create({
  baseURL,
  timeout: 10000,
  withCredentials: false,
});

// начальная установка токена
try {
  const t = localStorage.getItem("accessToken");
  if (t) {
    http.defaults.headers.common["Authorization"] = `Bearer ${t}`;
  }
} catch {
  // ignore
}

// перехватчик запросов — добавляем accessToken из localStorage
http.interceptors.request.use(
  (config) => {
    try {
      const token = localStorage.getItem("accessToken");
      if (token) {
        config.headers = config.headers || {};
        if (!config.headers["Authorization"]) {
          config.headers["Authorization"] = `Bearer ${token}`;
        }
      }
    } catch {
      // ignore
    }
    return config;
  },
  (err) => Promise.reject(err)
);

// обработка ошибок
http.interceptors.response.use(
  (res) => res,
  (err) => {
    if (err?.response?.status === 401) {
      console.warn("[HTTP 401]:", err?.config?.url);
      // сюда потом можно прикрутить авто-refresh по refreshToken
    }
    return Promise.reject(err);
  }
);

export default http;
